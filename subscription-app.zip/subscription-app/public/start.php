<?php
require __DIR__ . '/../app/config/db.php';
$userId = 1; 
$planId = isset($_GET['plan_id']) ? (int)$_GET['plan_id'] : 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $planId = (int)($_POST['plan_id'] ?? 0);

  $pstmt = $pdo->prepare("SELECT price_cents, billing_cycle FROM plans WHERE id=?");
  $pstmt->execute([$planId]);
  $plan = $pstmt->fetch();
  if (!$plan) { http_response_code(400); exit('Invalid plan'); }

  $start = date('Y-m-d');
  $end = $plan['billing_cycle'] === 'yearly'
        ? date('Y-m-d', strtotime('+1 year'))
        : date('Y-m-d', strtotime('+1 month'));

  try {
    $pdo->beginTransaction();

    $stmt = $pdo->prepare("INSERT INTO subscriptions (user_id, plan_id, start_date, end_date, status, next_renewal_on, auto_renew)
                           VALUES (?, ?, ?, ?, 'active', ?, 1)");
    $stmt->execute([$userId, $planId, $start, $end, $end]);
    $subId = (int)$pdo->lastInsertId();

    // payment row
    $pay = $pdo->prepare("INSERT INTO payments (subscription_id, user_id, amount_cents, status)
                          VALUES (?, ?, ?, 'succeeded')");
    $pay->execute([$subId, $userId, (int)$plan['price_cents']]);

    $pdo->commit();
    header("Location: subs.php?created={$subId}");
    exit;
  } catch (Throwable $e) {
    $pdo->rollBack();
    http_response_code(500);
    exit('Error creating subscription.');
  }
}

$pstmt = $pdo->prepare("SELECT id, name, price_cents, billing_cycle FROM plans WHERE id=?");
$pstmt->execute([$planId]);
$plan = $pstmt->fetch();
if (!$plan) { http_response_code(404); exit('Plan not found'); }
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Start Subscription</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-5">
  <h1 class="mb-3">Subscribe to <?= htmlspecialchars($plan['name']) ?></h1>
  <p class="mb-4">Price: <strong>$<?= number_format($plan['price_cents']/100, 2) ?></strong> / <?= htmlspecialchars($plan['billing_cycle']) ?></p>
  <form method="post" class="card p-3 shadow-sm">
    <input type="hidden" name="plan_id" value="<?= (int)$plan['id'] ?>">
    <button class="btn btn-success">Confirm Subscription</button>
    <a href="index.php" class="btn btn-outline-secondary ms-2">Cancel</a>
  </form>
</div>
</body>
</html>
