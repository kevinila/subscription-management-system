<?php
require __DIR__ . '/../app/config/db.php';
$userId = 1;

$sql = "
SELECT s.id,
       p.name AS plan_name,
       s.status,
       s.start_date,
       s.end_date,
       s.next_renewal_on,
       pay.status AS last_payment_status,
       pay.paid_at AS last_paid_at,
       pay.amount_cents AS last_amount_cents
FROM subscriptions s
JOIN plans p ON p.id = s.plan_id
LEFT JOIN (
  SELECT pr.subscription_id, pr.status, pr.paid_at, pr.amount_cents
  FROM payments pr
  JOIN (
    SELECT subscription_id, MAX(paid_at) AS max_paid
    FROM payments
    GROUP BY subscription_id
  ) m ON m.subscription_id = pr.subscription_id AND m.max_paid = pr.paid_at
) pay ON pay.subscription_id = s.id
WHERE s.user_id = ?
ORDER BY s.id DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute([$userId]);
$subs = $stmt->fetchAll();
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Your Subscriptions</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-5">

  <?php if (isset($_GET['created'])): ?>
    <div class="alert alert-success">Subscription #<?= (int)$_GET['created'] ?> created.</div>
  <?php endif; ?>
  <?php if (isset($_GET['renewed'])): ?>
    <div class="alert alert-success">Subscription #<?= (int)$_GET['renewed'] ?> renewed.</div>
  <?php endif; ?>

  <h1 class="mb-4 text-center">Your Subscriptions</h1>

  <table class="table table-striped shadow-sm">
    <thead>
      <tr>
        <th>ID</th><th>Plan</th><th>Status</th><th>Start</th><th>End</th><th>Last Payment</th><th>Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($subs as $s): ?>
      <tr>
        <td><?= (int)$s['id'] ?></td>
        <td><?= htmlspecialchars($s['plan_name']) ?></td>
        <td><?= htmlspecialchars($s['status']) ?></td>
        <td><?= htmlspecialchars($s['start_date']) ?></td>
        <td><?= htmlspecialchars($s['end_date']) ?></td>
        <td><?= htmlspecialchars($s['next_renewal_on'] ?? '—') ?></td>
        <td>
          <?php if ($s['last_payment_status']): ?>
            <?= htmlspecialchars($s['last_payment_status']) ?>
            <?php if ((int)($s['last_amount_cents'] ?? -1) === 0): ?>
              — Free
            <?php elseif ($s['last_amount_cents'] !== null): ?>
              — $<?= number_format($s['last_amount_cents']/100, 2) ?>
            <?php endif; ?>
            <?= $s['last_paid_at'] ? ' @ '.htmlspecialchars($s['last_paid_at']) : '' ?>
          <?php else: ?>
            —
          <?php endif; ?>
        </td>
        <td>
          <?php if ($s['status'] === 'active'): ?>
            <a class="btn btn-sm btn-outline-success" href="renew.php?id=<?= (int)$s['id'] ?>">Renew</a>
          <?php else: ?>
            —
          <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

  <a href="index.php" class="btn btn-outline-primary">Back to Plans</a>
</div>
</body>
</html>