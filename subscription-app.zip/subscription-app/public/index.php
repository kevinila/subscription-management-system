<?php require __DIR__ . '/../app/config/db.php'; ?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Subscription Manager</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-4">
  <h1 class="mb-4 text-center">Available Plans</h1>
  <?php
  $plans = $pdo->query("SELECT * FROM plans")->fetchAll();
  ?>
  <div class="row g-3">
    <?php foreach ($plans as $plan): ?>
    <div class="col-md-4">
      <div class="card h-100 shadow-sm">
        <div class="card-body">
          <h5><?= htmlspecialchars($plan['name']) ?></h5>
          <p><?= htmlspecialchars($plan['description']) ?></p>
          <p><strong>$<?= number_format($plan['price_cents']/100, 2) ?>/<?= $plan['billing_cycle'] ?></strong></p>
          <a href="start.php?plan_id=<?= (int)$plan['id'] ?>" class="btn btn-primary mt-2">Subscribe</a>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</div>
</body>
</html>
