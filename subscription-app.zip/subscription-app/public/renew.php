<?php
require __DIR__ . '/../app/config/db.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();

$userId = 1; 
$subId  = (int)($_GET['id'] ?? 0);

try {
  $pdo->beginTransaction();

  $q = $pdo->prepare("
    SELECT s.*, p.price_cents, p.billing_cycle
    FROM subscriptions s
    JOIN plans p ON p.id = s.plan_id
    WHERE s.id = ? AND s.user_id = ? AND s.status = 'active'
    FOR UPDATE
  ");
  $q->execute([$subId, $userId]);
  $s = $q->fetch();

  if (!$s) {
    throw new Exception('Subscription not found, not owned by user, or not active.');
  }

  $amount = (int)$s['price_cents'];
  $pdo->prepare("
    INSERT INTO payments (subscription_id, user_id, amount_cents, status)
    VALUES (?, ?, ?, 'succeeded')
  ")->execute([$subId, $userId, $amount]);

  $end  = new DateTime($s['end_date']);
  $next = new DateTime($s['next_renewal_on'] ?: $s['end_date']);

  if ($s['billing_cycle'] === 'yearly') {
    $end->modify('+1 year');
    $next->modify('+1 year');
  } else {
    $end->modify('+1 month');
    $next->modify('+1 month');
  }

  $u = $pdo->prepare("UPDATE subscriptions SET end_date=?, next_renewal_on=? WHERE id=?");
  $u->execute([$end->format('Y-m-d'), $next->format('Y-m-d'), $subId]);

  $pdo->commit();
  header("Location: subs.php?renewed={$subId}");
  exit;
} catch (Throwable $e) {
  if ($pdo->inTransaction()) $pdo->rollBack();
  http_response_code(500);
  echo "Error renewing subscription.";
}